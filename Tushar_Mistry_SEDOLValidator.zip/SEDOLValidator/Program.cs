﻿using System;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace SEDOLValidator
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("SEDOL Validator!");

			var sedolValidator = new SedolValidator();
			
			///Hover over each object below to see the content
			var res1=sedolValidator.ValidateSedol("0709954"); ShowAllProperties(res1);  //returns true; 
			res1 = sedolValidator.ValidateSedol(null);		  ShowAllProperties(res1);	//returns false for invalid length
			res1 = sedolValidator.ValidateSedol("");		  ShowAllProperties(res1);	//returns false for invalid length
			res1 = sedolValidator.ValidateSedol("123456789"); ShowAllProperties(res1);	//returns false for invalid length
			res1 = sedolValidator.ValidateSedol("9ABCDE8");   ShowAllProperties(res1);	// returns false 
			res1 = sedolValidator.ValidateSedol("9123_51");   ShowAllProperties(res1);  //returns false for invalid character

		}
		internal static void ShowAllProperties(ISedolValidationResult obj)
		{
			Console.WriteLine( string.Join(";", obj.GetType()
										.GetProperties()
										.Select(prop => prop.Name + ":"+ prop.GetValue(obj))));
		}
	}

	public class SedolValidator : ISedolValidator
	{
		private const byte OffSetValue = 9;
		public ISedolValidationResult ValidateSedol(string input)
		{
			string errMessage = string.Empty;
			
			if (string.IsNullOrEmpty(input) || input.Length != 7)
			{
				errMessage = "Input string was not 7-characters long";
			}
			else if (!Regex.IsMatch(input, "^[A-Z0-9]+$"))
			{
				errMessage = "SEDOL contains invalid characters";
			}
			else
			{
				var ipArray = ConvertToCheckSumArray(input);

				//Calculate Checksum
				var weightedSumTotal = ipArray[0] + ipArray[1] * 3 + ipArray[2] + ipArray[3] * 7 + ipArray[4] * 3 + ipArray[5] * 9;
				var chekSumTotal = (10 - (weightedSumTotal % 10)) % 10;
								                    
				if (chekSumTotal != ipArray[6]) // ipArray[6] is CheckDigitValue
				{
					errMessage = "Checksum digit does not agree with the rest of the input";
				}
			}

			//IsUserDefined logic is not specified in provided text
			return new SedolResult() {InputString= input, 
									 IsValidSedol = string.IsNullOrEmpty(errMessage)?true:false, 
									 IsUserDefined = CheckIsUserDefined(input),
									 ValidationDetails = errMessage };
		}

		private bool CheckIsUserDefined(string input)
		{
			if(!string.IsNullOrEmpty(input) && input.Substring(0, 1) == "9")
					return true;

			return false;
		}
		private byte[] ConvertToCheckSumArray(string input)
		{
			return input.ToCharArray().Select(c=> ConvertToCheckSumNumber(c.ToString())).ToArray();
			
		}
		private byte ConvertToCheckSumNumber(string element)
		{
			byte value;
			if (byte.TryParse(element, out value))
			{
				return value;
			}
			byte posA = 64;//ASCII value of A ie.65 - 1

			byte[] charByte = Encoding.ASCII.GetBytes(element);

			var alphabetPosition = charByte[0]-posA;

			return (byte)(OffSetValue + alphabetPosition);
		}
	}


	public class SedolResult : ISedolValidationResult
	{
		public string InputString { get; set; }

		public bool IsValidSedol { get; set; }

		public bool IsUserDefined { get; set; }

		public string ValidationDetails { get; set; }
	}
}
